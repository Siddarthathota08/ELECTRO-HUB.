window.PRODUCTS = [
  {
    "id": 1,
    "name": "Atom X1 Smartphone",
    "price": 16999,
    "category": "Mobiles",
    "image": "assets/img/phone.png",
    "rating": 4.5
  },
  {
    "id": 2,
    "name": "Orion 14\" Laptop",
    "price": 56999,
    "category": "Laptops",
    "image": "assets/img/laptop.jpg",
    "rating": 4.6
  },
  {
    "id": 3,
    "name": "WavePods Wireless",
    "price": 3299,
    "category": "Audio",
    "image": "assets/img/earbuds.jpg",
    "rating": 4.2
  },
  {
    "id": 4,
    "name": "Nebula 50\" 4K TV",
    "price": 34999,
    "category": "Televisions",
    "image": "assets/img/tv.jpg",
    "rating": 4.4
  },
  {
    "id": 5,
    "name": "Photon Mirrorless Cam",
    "price": 70999,
    "category": "Cameras",
    "image": "assets/img/camera.jpg",
    "rating": 4.7
  },
  {
    "id": 6,
    "name": "Atom X1 Pro",
    "price": 23999,
    "category": "Mobiles",
    "image": "assets/img/phone.jpeg",
    "rating": 4.8
  },
  {
    "id": 7,
    "name": "Orion 16\" Creator",
    "price": 79999,
    "category": "Laptops",
    "image": "assets/img/laptop.png",
    "rating": 4.4
  },
  {
    "id": 8,
    "name": "WavePods Max",
    "price": 6499,
    "category": "Audio",
    "image": "assets/img/earbuds.jpeg",
    "rating": 4.3
  },
  {
    "id": 9,
    "name": "Nebula 50\" 4K TV",
    "price": 34999,
    "category": "Televisions",
    "image": "assets/img/tv.png",
    "rating": 4.4
  },
  {
    "id": 10,
    "name": "Photon Mirrorless Cam",
    "price": 70999,
    "category": "Cameras",
    "image": "assets/img/camera.png",
    "rating": 4.7
  },
];