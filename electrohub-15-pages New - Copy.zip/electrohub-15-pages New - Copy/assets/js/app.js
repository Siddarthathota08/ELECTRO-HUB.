
(function(){
  const CART_KEY='eh_cart', WISHLIST_KEY='eh_wishlist', USER_KEY='eh_user';
  const $ = s=>document.querySelector(s);
  const $$ = s=>Array.from(document.querySelectorAll(s));
  const fmt = n => '₹ ' + n.toLocaleString('en-IN');

  function getArr(k){ try{ return JSON.parse(localStorage.getItem(k)||'[]')}catch{ return []} }
  function setArr(k, v){ localStorage.setItem(k, JSON.stringify(v)); }
  function getUser(){ try{ return JSON.parse(localStorage.getItem(USER_KEY)||'{}')}catch{ return {} } }
  
  


  window.App = {
    addToCart(id, qty=1){
      const cart = getArr(CART_KEY); const row = cart.find(x=>x.id==id);
      if(row){ row.qty += qty } else { cart.push({id, qty}) }
      setArr(CART_KEY, cart); App.sync();
      App.toast('Added to cart');
    },
    removeFromCart(id){ setArr(CART_KEY, getArr(CART_KEY).filter(x=>x.id!=id)); App.sync(); },
    setQty(id, qty){ const cart=getArr(CART_KEY); const r=cart.find(x=>x.id==id); if(r){r.qty=Math.max(1,qty)}; setArr(CART_KEY, cart) },
    cart(){ return getArr(CART_KEY).map(it=>{ const p=(window.PRODUCTS||[]).find(x=>x.id==it.id); return {...p, qty:it.qty, line:p.price*it.qty} }) },
    addToWish(id){ const s=new Set(getArr(WISHLIST_KEY)); s.add(id); setArr(WISHLIST_KEY, Array.from(s)); App.sync(); App.toast('Saved to wishlist') },
    removeWish(id){ setArr(WISHLIST_KEY, getArr(WISHLIST_KEY).filter(x=>x!=id)); App.sync(); },
    wishlist(){ return getArr(WISHLIST_KEY).map(id=>(window.PRODUCTS||[]).find(p=>p.id==id)).filter(Boolean) },
    sync(){
      const c = getArr(CART_KEY).reduce((a,b)=>a+b.qty,0); const w = getArr(WISHLIST_KEY).length;
      $$('.badge.cart').forEach(b=>b.textContent=c); $$('.badge.wish').forEach(b=>b.textContent=w);
      const u = getUser(); $$('.user-name').forEach(el=> el.textContent = (u&&u.name) ? u.name : 'Guest');
    },
    fmt,
    toast(msg){ const t=document.createElement('div'); t.textContent=msg; t.style.position='fixed'; t.style.bottom='20px'; t.style.left='50%'; t.style.transform='translateX(-50%)'; t.style.background='rgba(0,0,0,.8)'; t.style.color='white'; t.style.padding='10px 14px'; t.style.borderRadius='10px'; t.style.zIndex=9999; document.body.appendChild(t); setTimeout(()=>t.remove(),1200); },
    renderProducts(sel, list){
      const el = $(sel); if(!el) return;
      el.innerHTML = list.map(p=>`
        <div class="card product">
          <div class="img"><img src="${p.image}" alt="${p.name}" style="max-width:80%; max-height:80%"/></div>
          <div><div style="font-weight:700">${p.name}</div><div class="small">${p.category} • ★ ${p.rating}</div></div>
          <div class="price">
            <div style="font-weight:700">${App.fmt(p.price)}</div>
            <div class="flex">
              <button class="btn" onclick="App.addToCart(${p.id})">Add</button>
              <button class="btn ghost" onclick="App.addToWish(${p.id})">♥</button>
            </div>
          </div>
          <a class="small" href="product.html?id=${p.id}">View details →</a>
        </div>`).join('');
    },
    searchAndFilter({q='', category='All'}){
      q = q.trim().toLowerCase();
      return (window.PRODUCTS||[]).filter(p=>{
        const okQ = !q || p.name.toLowerCase().includes(q);
        const okC = category == 'All' || p.category.toLowerCase() == category.toLowerCase();
        return okQ && okC;
      });
    }
  };

  document.addEventListener('DOMContentLoaded', ()=>{
    App.sync();
    const search = document.getElementById('searchBox');
    const cat = document.getElementById('categorySelect');
    if(search || cat){
      const run = ()=>{
        const list = App.searchAndFilter({ q: search?search.value:'', category: cat?cat.value:'All' });
        App.renderProducts('#productGrid', list);
      };
      if(search) search.addEventListener('input', run);
      if(cat) cat.addEventListener('change', run);
      run();
    }
  });
})();
